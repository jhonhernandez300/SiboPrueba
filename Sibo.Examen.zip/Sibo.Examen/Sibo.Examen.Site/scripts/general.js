﻿function Message(title, content) {
    $.msgBox({
        title: title,
        content: content,
        type: "info"
    });
}